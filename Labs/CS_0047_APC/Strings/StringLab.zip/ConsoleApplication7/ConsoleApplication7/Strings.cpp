#include "StringHelper.h";
#include <iostream>
#include <ctype.h>


/*

   Function Name:GetInput

	Inputs: Array of string pointers  ( You may use array notation.)

	Return: Nothing

	Description: This function accepts three lines of user-input text and store the entered lines as three individual strings.  
	Use a pointer array to store the strings.  
	The function should ask the user to enter in three lines of data.  
	The function will store the information in the pointer array.  (cin.getline()).  
	Should be allocated in inside GetInput and should be exactly the correct size for each string,

*/
void GetInput(char* arr[])
{
	char* buffer = new char[400];
	for (int i = 0; i < 3; i++)
	{
		std::cout << "Input string #" << i << ": ";
		std::cin.getline(buffer, 400); // gets string and puts it in buffer
		arr[i] = new char[strlen(buffer + 1)]; // puts it in the array with the correct size 
		strcpy_s(arr[i], strlen(buffer)+1, buffer); 
	}
}

void Search(char* arr[], const char* keyword)
{
	int count = 0;
	for (int i = 0; i < 3; i++)
	{
		char* ret = strstr(arr[i], keyword);
		if (ret != NULL)
		{
			std::cout << "String found in: " << arr[i] << std::endl;
			count++;
		}
		else
		{
			std::cout << "String not found!" << std::endl;
		}
	}

	
	std::cout << "Amount of strings with " << keyword << " is " << count << std::endl;
}

void Sort(char* arr[])
{	

	for (int i = 0; i < 3; i++)
	{
		for (int j = i+1; j < 3; j++)
		{
			if (strcmp(arr[i], arr[j]) > 0)
			{
				std::swap(arr[i], arr[j]);

			}
		}

	}
}

void DisplayStrings(char* arr[])
{
	for (int i = 0; i < 3; i++)
	{
		std::cout << arr[i] << std::endl;
	}
}

void ShowLens(char* arr[])
{
	for (int i = 0; i < 3; i++)
	{
		std::cout << strlen(arr[i]) << std::endl;
	}
}
int AlphaChars(char* arr[])
{
	// asdasdasd 
	// + 
	// asdasd123

	int count = 0;
	for (int i = 0; i < 3; i++)
	{
		for (int k = 0; k < strlen(arr[i] + 1); k++)
		{
			if (isalpha(arr[i][k]))
			{
				count++;
			}
		}
	}
	std::cout << count << std::endl;
	return count;
}