#include <iostream>
#include "StringHelper.h"


using namespace std;

int main() 
{
    char* arr[3];            // Declare an array of string pointers. There should be three elements.
    GetInput(arr); 
    std::cout << std::endl; // Get user input by calling GetInput function. 
    DisplayStrings(arr);
    std::cout << std::endl;    // Display the strings. 
    Search(arr, "love");
    std::cout << std::endl;    // Search for the string "love" by calling the search function. 
    Sort(arr);
    std::cout << std::endl; // Sort the strings. 
    DisplayStrings(arr); 
    std::cout << std::endl;  // Display the strings by calling the function DisplayStrings.
    ShowLens(arr);   
    std::cout << std::endl;    // Display the lenghths by calling the function ShowLens.
    AlphaChars(arr);        // Print the total number of alphabetic characters by calling AlphaChars. 
}