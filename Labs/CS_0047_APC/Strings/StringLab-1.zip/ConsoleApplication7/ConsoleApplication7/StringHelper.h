#pragma once
void GetInput(char* arr[]);
void Search(char* arr[], const char* keyword);
void Sort(char* arr[]);
void DisplayStrings(char* arr[]);
void ShowLens(char* arr[]);
int AlphaChars(char* arr[]);