
/*
    Damon Montague

*/
#include <iostream>
using namespace std;


int main()
{
    double x;
    int y;
    string cont = "yes";



    do {

        cout << "enter amount: " << endl;
        cin >> x;
        y = x * 100;
        // 100.82 = 10082
        cout << "Hundred dollar bills: " << y / 10000 << endl;
        y %= 10000;

        cout << "Fifty dollar bills: " << y / 5000 << endl;
        y %= 5000;

        cout << "Twenty dollar bills: " << y / 2000 << endl;
        y %= 2000;

        cout << "Ten dollar bills: " << y / 1000 << endl;
        y %= 1000;

        cout << "Five dollar bills: " << y / 500 << endl;
        y %= 500;

        cout << "Dollar bills: " << y / 100 << endl;
        y %= 100;

        //Coins
        cout << "Quaters: " << y / 25 << endl;
        y %= 25;

        cout << "Dimes: " << y / 10 << endl;
        y %= 10;

        cout << "Nickles: " << y / 5 << endl;
        y %= 5;

        cout << "Pennies: " << y / 1 << endl;

        cout << "Do you want to continue?: ";
        cin >> cont;

    } while (cont == "yes");

}