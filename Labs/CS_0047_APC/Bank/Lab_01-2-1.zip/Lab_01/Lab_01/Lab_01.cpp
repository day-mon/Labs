/*
    Damon Montague

*/
#include <iostream>
using namespace std;


int main()
{
    double x;
    int y;
    string cont = "yes";



    do {
        cout << "enter amount: " << endl;
        cin >> x;
        y = x * 100;
        // 100.82 = 10082



        int  hundred = y;
        y %= 10000;

        int fifty = y;
        y %= 5000;


        int twenty = y;
        y %= 2000;


        int tens = y;
        y %= 1000;


        int five = y;
        y %= 500;

        int one = y;
        y %= 100;

        //Coins

        int quat = y;
        y %= 25;


        int dime = y;
        y %= 10;


        int nick = y;
        y %= 5;


        int pen = y;

        cout << "Pennies: " << pen << endl;
        cout << "Nickles: " << nick / 5 << endl;
        cout << "Dimes: " << dime / 10 << endl;
        cout << "Quaters: " << quat / 25 << endl;
        cout << "Dollar bills: " << one / 100 << endl;
        cout << "Five dollar bills: " << five / 500 << endl;
        cout << "Ten dollar bills: " << tens / 1000 << endl;
        cout << "Twenty dollar bills: " << twenty / 2000 << endl;
        cout << "Fifty dollar bills: " << fifty / 5000 << endl;
        cout << "Hundred dollar bills: " << hundred / 10000 << endl;

        cout << "Do you want to continue?: ";
        cin >> cont;

    } while (cont == "yes");

}