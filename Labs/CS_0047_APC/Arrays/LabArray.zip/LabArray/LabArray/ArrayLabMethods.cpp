#include <iostream>
#include <ctime>
#include "Methods.h"

static short int checksum = 0;

/*
Function Name: DisplayArray
       Inputs: A pointer to a short int
       Return: nothing
       Description: This function will take as a parameter a pointer to a short int.
       This should be a pointer to an array.
       The function shall loop thru and print out each element of the array include the first element.
       The array should be displayed horizontally on the screen.
       There should be a space between each element printed and a line break after the last element is printed.
*/

void DisplayArray(short int* a)
{
    for (int i = 0; i < *a; i++)
    {
        std::cout << *(a + i) << " ";
    }
    std::cout << std::endl;
}

/*

        Function Name:ConcatArray
        Inputs: This function takes in two parameters.  Both parameters are pointers to short ints which refer to arrays.
        Return: This returns the address of new array that was created using dynamic memory allocation.
        Description: This function take in two pointers as parameters.  These pointers are pointers to arrays.   
        The function will create a new array using dynamic memory allocation.  
        The new array will consist of ALL of the elements in the first array and all of the elements in the second array.  
        The two arrays will simply be concatenated together in a new array.  The function will return the address of the new array.
*/
short int* ConcatArray(short int* a1, short int* a2)
{
    short int arrSize = *a1+*a2+1;
    short int* newarr = new short int[arrSize];

    *newarr = arrSize;
    int s = 0;
    for (int i = 0; i < *a1; i++)
    {
        *(newarr + i + 1) = *(a1 + i);

         s = i+1;
       
    }


    for (int i = s; i < arrSize-1; i++)
    {
        *(newarr + i + 1) = *(a2 + (i - *a1));
    }

    return newarr;
}

void ReverseArray(short int* arr)
{
    int size = *arr; // EX: SIZE = 10

    if (size == 1) return;

    for (int i = 1; i < size/2; i++) // we dont even need first index because thats the size silly...
    {
        short int temp = *(arr + (size - i));
        *(arr + (size - 1)) = *(arr + i);
        *(arr + i) = temp;

    }
    
}


short int* GetArrayN(short int* orig, int n)
{
    if (n == 1)
    {
        short int size = *(orig + 1);
        short int* f = new short int[size];


        for (int i = 0; i < size; i++)
        {
            *(f + i ) = *(orig + i + 1);
        }
        return f;
    }
    else
    {
        short int size = *(orig + *(orig + 1) + 1);
        short int *e = new short int[size];

  
        for (int i = 0, p = size -1 ; i < size; i++, p++) 
        {
            *(e + i) = *(orig + p);
        }

        return e;
    }
}

void ScrambleArray(short int* a)
{
    if (checksum == 0) {                      
        srand(time(NULL));                  
        checksum = 1;                        
    }
    for (int i = *a -1; i > 1; i--) 
    {          
        int o = rand() % 1 + 1;
        int t = *(a + o);
        *(a + o) = *(a + i);
        *(a + i) = t;
    }

    // https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle
}
