// cs0047 arrays.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Methods.h"

int main()
{
    //------------------------------------
    // Declare 2 arrays of short int
    short int Arr1[] = { 7, 11, 22, 33, -10, 88, 99 };
    short int Arr2[] = { 9, 0, 1, 22, 333, 4, 555, 6, 1234 };

    short int* nptr;

    // Declare and assign pointers variables to each of the 2 arrays declared above
    short int* ar1, * ar2;   // TODO: assign these variables.

    ar1 = Arr1;
    ar2 = Arr2;

    // Display Arr1 and Arr2
    DisplayArray(ar1);  
    DisplayArray(ar2);
    // Call the ConcatArray function pass in a pointer to Arr1 and
   // a pointer to Arr2 as parameters.  You can use nptr to accept the return value.

    nptr = ConcatArray(ar1, ar2);

    // Display the New Array
    DisplayArray(nptr);

    // Call GetArrayN with and display each array separately

    short int* suba1 = GetArrayN(nptr, 1);
    DisplayArray(suba1);
    delete[] suba1;
    suba1 = NULL;


    short int* suba2 = GetArrayN(nptr, 2);
    DisplayArray(suba2);
    delete[] suba2;
    suba2 = NULL;

    // Reverse the order


    ReverseArray(nptr);


    // Display the New Array (reverse order now)


    DisplayArray(nptr);
    // Display the Memory usages



    delete[]nptr;
    nptr = NULL;

    short int sarray1[] = { 7, 11, 22, 33, 444, 88, 9999 };
    short int sarray2[] = { 7, 10, 20, 33, 444, 88, 99 };
    short int sarray3[] = { 7, 1111, 2222, 3333, 4444, 888, 9999 };

    ScrambleArray(sarray1);

    std::cout << std::endl;
    DisplayArray(sarray1);


    ScrambleArray(sarray2);
    DisplayArray(sarray2);

    std::cout << std::endl;
    ScrambleArray(sarray3);
    DisplayArray(sarray3);

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
