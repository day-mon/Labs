#pragma once
void DisplayArray(short int* a);

short int* ConcatArray(short int* a1, short int* a2);

short int* GetArrayN(short int* orig, int n);

void ReverseArray(short int* arr);

void ScrambleArray(short int* a);