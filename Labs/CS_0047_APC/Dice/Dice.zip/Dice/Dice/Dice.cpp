// Dice.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <time.h> 
#include <ctime>

using namespace std;

int wins, loses, money = 0;

void defaultwin() 
{
    wins++;
    money += 9;
    cout << "===================\n"
        "You won! \nYou won $9"
        "\nCurrent stats:"
        "\nWins: " << wins << " & " << "Loses: " << loses <<
        "\nMoney: $" << money <<
        "\n===================" << endl;
}

void sevenWin()
{
    wins++;
    money += 10;
    cout << "===================\n"
        "You won! \nYou won $9"
        "\nCurrent stats:"
        "\nWins: " << wins << " & " << "Loses: " << loses <<
        "\nMoney: $" << money <<
        "\n===================" << endl;
}

void lose()
{
    loses++;
    money -= 10;
    cout << "===================\n"
        "You lost! \nYou lost $10" <<
        "\nCurrent stats: " <<
        "\nWins: " << wins << " & " << "Loses: " << loses <<
        "\nMoney: $" << money <<
        "\n===================" << endl;
}



int roll()
{
    return (rand() % 6) + 1;
}

void roll50k()
{
    int numbers[] = { 0, 0, 0, 0, 0, 0 };
    for (int i = 0; i < 50000; i++) 
    {
        int dieRoll = roll();
        numbers[dieRoll - 1]++;
    }

    for (int i = 0; i < 6; i++) 
    {
        cout << "Times " << i+1 << " rolled: " << numbers[i] << endl;
    }
}



int main() 
{   
    int seed = 0;
    cout << "Enter a seed: ";
    cin >> seed;

    // srand = seed random
    srand(seed < 0 ? (time(NULL) % 6) + 1 : seed);
    char rollC;

    do {
       
        int r1, r2, rt;
        cout << "Start: Press r to roll: ";
        cin >> rollC;
        
        r1 = roll();
        r2 = roll();
        // bilitski this is bad 
        rt = (rollC == 'q'  ? -1 : r1 + r2);

        if (rt == 7 ) {
            cout << "You rolled a " << rt << endl;
            sevenWin();

        }
        else if (rt == 11) {
            cout << "You rolled a " << rt << endl;
            defaultwin();
        }
        else if (rt == 2 || rt == 3 || rt == 10 || rt == 12 ) {
            cout << "You rolled a " << rt << endl;
            lose();
        } else if (rt == 4 || rt == 5 || rt == 6 || rt == 8 || rt == 9) {
            cout << "You rolled a " << rt << "! \nYou have to continue you rolling until you hit the target number which is: (" << rt << ") or you hit in 7 in which case you lose! \nGood luck!" << endl;
            while (1 == 1) {
                int rL1, rL2, rLt;
                char response;
                cout << "Press r to roll: ";
                cin >> response;

                rL1 = roll();
                rL2 = roll();
                rLt = rL1 + rL2;

                cout << "You rolled a " << rLt << endl;

                if (rt == rLt) {
                    cout << "You hit the target!" << endl;
                    defaultwin();
                    break;
                }
                else if (rLt == 7) {
                    cout << "You hit 7 " << endl;
                    money += 1;
                    lose();
                    break;
                }
                
            
            }
            
            
        }




    } while (rollC != 'q');


    roll50k();

      
    

}

