#include "ListH.h"
#include "RecordH.h"
#include <iostream>

List::List() // fine
{
	this->first = NULL;
	this->last = NULL;
}

int List::Add(Record r)
{
	if (isDuplicate(r.id))
	{
		std::cout << "You are trying to add a duplicate id";
		return 0;
	}

	if (r.id == NULL  || r.firstName == NULL || r.lastName == NULL || r.id == "" || r.firstName == "" || r.lastName == "" )
	{
		std::cout << "You are missing firstname or last name or id" << std::endl;
		return 0;
	}



	Record* record = new Record(r.id, r.firstName, r.lastName);



	if (this->first == NULL && this->last == NULL)
	{
		this->first = record;
		this->last = record;
		record->next = NULL;
		record->prev = NULL;
		return 1;
	}

	Record* current = this->first;


	while (current)
	{
		if (strcmp(record->lastName, current->lastName) < 0)
		{
			break;
		}
		current = current->next;
	}

	if (current == NULL)
	{
		record->next = NULL;
		record->prev = last;
		last->next = record;
		last = record;
		return 1;
	}
	else if (current->prev == NULL)
	{
		record->prev = NULL;
		record->next = first;
		first->prev = record;
		first = record;
		return 1;
	}
	else
	{
		
		record->prev = current->prev;
		record->next = current;
		current->prev->next = record;
		current->prev = record;
		return 1;
	}	
}

int List::Delete(const char* id)
{

	if (this->first == NULL || id == NULL)
	{
		return 0;
	}

	Record* current = this->first;

	while (current)
	{
		if (current->id)
		{
			if (strcmp(current->id, id) == 0)
			{
				break;
			}
		}
		current = current->next;
	}

	if (current == NULL)
	{
		// Nothing found.??
		return 0;
	}

	Record* rp = current->prev;
	Record* rn = current->next;

	if (current == this->first && current == this->last)
	{
		this->first = NULL;
		this->last = NULL;
	}
	else if (rp == NULL)
	{
		rn->prev = NULL;
		this->first = rn;
	}
	else if (rn == NULL) 
	{
		rp->next = NULL;
		this->last = rp;
	}
	else 
	{
		rp->next = rn;
		rn->prev = rp;
	}
	delete current;
	return 1;

}

void List::Print(int order)
{
	Record* current;
	switch (order)
	{
	case 0:
		current = first;
		while (current)
		{
			current->Print();
			current = current->next;
		}
		break;
	case 1:
		current = last;
		while (current)
		{
			current->Print();
			current = current->prev;
		}
		break;
	default:
		printf("%d is not a valid entry. Please try 0 or 1", order);
	}
}

void List::operator=(const List& _list)
{
	Record* current = this->first;

	while (current)
	{
		current->~Record();
		// Gotta deconstruct and remove;
		current = current->next;
	}
	current = _list.first;

	while (current)
	{
		Add(*current);
		// NO more redundant code :>
		current = current->next;
	}
}


bool List::isDuplicate(const char* id)
{
	Record* current = this->first;

	while (current)
	{
		if (current->id)
		{
			if (strcmp(current->id, id) == 0)
			{
				return true;
			}
		}
		current = current->next;
	}
	return false;
}