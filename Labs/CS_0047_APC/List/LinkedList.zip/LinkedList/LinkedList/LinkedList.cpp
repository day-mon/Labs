
#include <iostream>
#include "RecordH.h"
#include "ListH.h"
using namespace std;

int main()
{

	// Testing constructors
	cout << "  ------ Testing rec1 ---------------" << endl;
	Record rec1;  // calls default constructor for Record
	rec1.Print();


	cout << "  ------ Testing rec2 ---------------" << endl;
	Record rec2(NULL, "Joe", "Smith");
	rec2.Print(); // constructor using NULL ID


	cout << "  ------ Testing rec3 ---------------" << endl;
	Record rec3("111111", "Hank", "Chigla"); // constructor using all normal strings
	rec3.Print();



	cout << "  ------ Testing rec4 ---------------" << endl;
	Record rec4("22222", NULL, NULL);
	rec4.Print();

	cout << "  ------ Testing rec5 ---------------" << endl;
	Record rec5 = rec1; // test copy constructor
	rec5.Print();


	cout << "  ------ Testing rec6 ---------------" << endl;
	Record rec6 = rec3; // test copy constructor
	rec6.Print();


	// Testing SetData
	cout << "  ------ Testing rec7 ---------------" << endl;
	rec1.SetData(NULL, NULL, NULL);
	rec1.Print();

	cout << "  ------ Testing rec2 ---------------" << endl;
	rec2.SetData(NULL, "Sasha", "Lacey");
	rec2.Print();

	cout << "  ------ Testing rec3 ---------------" << endl;
	rec3.SetData("456", "Fiona", "Louise");
	rec3.Print();

	// Testing operator=
	Record rec7;
	Record rec8;

	cout << "  ------ Testing rec7 ---------------" << endl;
	rec7 = rec8; // test operator=
	rec7.Print();


	cout << "  ------ Testing rec8 ---------------" << endl;
	rec7.SetData("888", "Stalker", "Thomas");
	rec8 = rec7;
	rec8.Print();


	// test empty list
	cout << " ------- LIST TESTING  -------- " << endl;
	List myList;
	myList.Print(0);  // test printing empty list


	cout << " ------- LIST TESTING invalid record  --------  " << endl;
	rec1.SetData(NULL, NULL, NULL);
	myList.Add(rec1);
	myList.Print(0);

	cout << " ------- LIST TESTING first record  --------  " << endl;
	rec1.SetData("123", "gg", "goodwin");
	myList.Add(rec1);
	myList.Print(0);

	cout << " ------- LIST TESTING delete only record   --------  " << endl;
	myList.Delete("123");
	myList.Print(0);


	cout << " ------- LIST TESTING first record again  --------  " << endl;
	rec1.SetData("123", "gg", "goodwin");
	myList.Add(rec1);
	myList.Print(0);



	cout << " ------- LIST TESTING duplicate id  123--------  " << endl;
	rec1.SetData("123", "h", "happy");
	myList.Add(rec1);
	myList.Print(0);

	cout << " ------- LIST TESTING add to back -------- monster " << endl;
	rec1.SetData("456", "m", "monster");
	myList.Add(rec1);
	myList.Print(0);


	cout << " ------- LIST TESTING add to back pappy --------  " << endl;
	rec1.SetData("456p", "p", "pappy");
	myList.Add(rec1);
	myList.Print(0);




	cout << " ------- LIST TESTING add to front  elephant  -------  " << endl;
	rec1.SetData("999", "e", "elephant");
	myList.Add(rec1);
	myList.Print(0);




	cout << " ------- LIST TESTING  middle igloo --------  " << endl;
	rec1.SetData("789i", "i", "igloo");
	myList.Add(rec1);
	myList.Print(0);

	cout << " ------- LIST TESTING  middle  lamp --------  " << endl;
	rec1.SetData("lllll", "ll", "lamp");
	myList.Add(rec1);
	myList.Print(0);





	cout << " ------- LIST TESTING   aaaaaapple --------  " << endl;
	rec1.SetData("324324", "aa", "aaaaaapple");
	myList.Add(rec1);
	myList.Print(0);


	cout << " ------- LIST TESTING  AAAAAAApple  --------  " << endl;
	rec1.SetData("AAAAAA", "AAA", "AAAAAAApple");
	myList.Add(rec1);
	myList.Print(0);


	cout << " ------- LIST TESTING Print reverse  --------  " << endl;
	myList.Print(1);


	cout << " ------- LIST TESTING zebra  --------  " << endl;
	rec1.SetData("zzzz", "zzzzz", "zebra");
	myList.Add(rec1);
	myList.Print(0);

	cout << " ------- LIST TESTING duplicate last name elephant  --------  " << endl;
	rec1.SetData("eeeeeee11111", "ee", "elephant");
	myList.Add(rec1);
	myList.Print(0);



	cout << " ------- LIST TESTING delete invalid record --------  " << endl;
	myList.Delete("sdfsdfgsdfgsdfgsdfgsdfgsdfgdsfgdg");


	cout << " ------- LIST TESTING delete middle id 123 --------  " << endl;
	myList.Delete("123");
	myList.Print(0);


	cout << " ------- LIST TESTING delete end id zzzz --------  " << endl;
	myList.Delete("zzzz");
	myList.Print(0);


	cout << " ------- LIST TESTING delete front id AAAAAA --------  " << endl;
	myList.Delete("AAAAAA");
	myList.Print(0);



	cout << " ------- LIST TESTING a copiedList --------  " << endl;
	List aCopiedList;
	aCopiedList = myList;
	aCopiedList.Print(0);

	myList.Delete("999");
	cout << " ------- LIST TESTING a copiedList DEEP COPY 999 here --------  " << endl;
	aCopiedList.Print(0);


	cout << " ------- LIST TESTING a copiedList DEEP COPY 999 gone --------  " << endl;
	myList.Print(0);

}
