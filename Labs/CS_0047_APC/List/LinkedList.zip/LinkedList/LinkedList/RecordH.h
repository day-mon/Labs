#pragma once
class Record {
    friend class List;
private:
    char* id;
    char firstName[20];
    char lastName[20];
    Record* next;
    Record* prev;

public:
    Record(const char* _id, const char* _fn, const char* _ln);
    Record(void);
    Record operator=(const Record& r);
    Record(const Record& r);
    void SetData(const char* _id, const char* _fn, const char* _ln);
    void Print();
    ~Record();
};