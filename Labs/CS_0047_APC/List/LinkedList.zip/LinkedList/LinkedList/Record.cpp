#include <iostream>
#include "RecordH.h"

Record::Record(const char* _id, const char* _fn, const char* _ln) // not broken
{
	if (_id == NULL)
	{
		this->id = NULL;
	}
	else
	{
		this->id = new char[strlen(_id) + 1];
		strcpy_s(id, strlen(_id) + 1, _id);
	}
	
	if (_fn == NULL)
	{
		this->firstName[0] = NULL;
	}
	else
	{
		strcpy_s(firstName, strlen(_fn) + 1, _fn);
	}

	if (_ln == NULL)
	{
		this->lastName[0] = NULL;
	}
	else
	{
		strcpy_s(lastName, strlen(_ln) + 1, _ln);
	}
	
	this->next = NULL;
	this->prev = NULL;

	//(_id == NULL ? this->id = NULL : this->id = (char*)_id);
	//(_fn == NULL ? this->firstName == NULL : strcpy_s(firstName, strlen(_fn)+1, _fn));
	//(_ln == NULL ? this->lastName == NULL : strcpy_s(firstName, strlen(_fn) + 1, _ln));
}

Record::Record() // not broken
{
	this->id			= NULL;
	this->firstName[0]  = NULL; 
	this->lastName [0]  = NULL; 
	this->next			= NULL;
	this->prev			= NULL;
}

Record::~Record() // not broken
{
	if (this->id != NULL)
	{
		delete[] this->id;
		this->id = NULL;
	}

}

Record Record::operator=(const Record& r) // works
{
	this->~Record();

	if (r.id == NULL)
	{
		this->id = NULL;
	}
	else
	{
		this->id = new char[strlen(r.id) + 1];
		strcpy_s(this->id, strlen(r.id) + 1, r.id);
	}

	if (r.firstName == NULL)
	{
		this->firstName[0] = NULL;
	}
	else
	{
		strcpy_s(this->firstName, strlen(r.firstName) + 1, r.firstName);
	}

	if (r.lastName == NULL)
	{
		this->lastName[0] = NULL;
	}
	else
	{
		strcpy_s(this->lastName, strlen(r.lastName) + 1, r.lastName);
	}

	this->prev = r.prev;
	this->next = r.next;	
	return Record();

}

Record::Record(const Record& r)
{
	if (r.id == NULL)
	{
		this->id = NULL;
	}
	else
	{
		this->id = new char[strlen(r.id) + 1];
		strcpy_s(this->id, strlen(r.id) + 1, r.id);
	}

	if (r.firstName == NULL)
	{
		this->firstName[0] = NULL;
	}
	else
	{
		strcpy_s(this->firstName, strlen(r.firstName) + 1, r.firstName);
	}

	if (r.lastName == NULL)
	{
		this->lastName[0] = NULL;
	}
	else
	{
		strcpy_s(this->lastName, strlen(r.lastName) + 1, r.lastName);
	}

	//(r.id == NULL ? this->id = NULL : this->id = new char[strlen(r.id) + 1]);	strcpy_s(this->id, strlen(r.id) + 1, r.id);
	//(r.firstName == NULL ? this->firstName[0] = NULL : this->firstName[0]   =   strcpy_s(this->firstName, strlen(r.firstName)+1, r.firstName));
	//(r.lastName  == NULL ? this->lastName[0]  = NULL : this->lastName[0]    =   strcpy_s(this->lastName, strlen(r.lastName)+1, r.lastName));
	this->next = r.next;
	this->prev = r.prev;
}

void Record::Print()
{
	if (this->id == NULL)
	{
		std::cout << "No ID" << " " << firstName << " " << lastName << " " << prev << " " << this << " " << next << std::endl;
	}
	else
	{
		std::cout << " " << this->id << " " << this->firstName << " " << this->lastName << " " << this->prev << " " <<  this << " " << this->next << " " << std::endl;
	}
}
void Record::SetData(const char* _id, const char* _fn, const char* _ln)
{
	this->~Record();
	if (_id == NULL)
	{
		this->id = NULL;
	}
	else
	{
		this->id = new char[strlen(_id) + 1];
		strcpy_s(id, strlen(_id) + 1, _id);
	}

	if (_fn == NULL)
	{
		this->firstName[0] = NULL;
	}
	else
	{
		strcpy_s(firstName, strlen(_fn) + 1, _fn);
	}

	if (_ln == NULL)
	{
		this->lastName[0] = NULL;
	}
	else
	{
		strcpy_s(lastName, strlen(_ln) + 1, _ln);
	}

}



