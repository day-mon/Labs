#pragma once
#include "RecordH.h"

class List {

private:
    Record* first;
    Record* last;

public:
    int Add(Record r);
    int Delete(const char* id);
    void Print(int order);
    List();
    void operator=(const List& _list);

private:
    bool isDuplicate(const char* id);
};