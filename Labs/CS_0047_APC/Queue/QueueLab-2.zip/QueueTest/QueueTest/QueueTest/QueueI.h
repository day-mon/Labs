#pragma once

int Enqueue(int num);
int Dequeue(int& num);
int IsEmpty();
int Exists(int num);
void Print();
void Clear();
int Reverse();
int Mul();
int Peek(int& num);