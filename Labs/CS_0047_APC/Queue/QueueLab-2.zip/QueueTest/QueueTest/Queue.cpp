// Queue.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <limits>
#include "QueueI.h"

static const int MAX_CAPCITY = 10;
static int queue[MAX_CAPCITY];
static int front = 0, back = 0, size = 0;

int Exists(int num)
{
	/*
		int Exists ( int num )
		return 1 if num exists in the queue.  Returns 0 if it does not exist.
	*/

	for (int i = front; i != back; i = (i + 1) % MAX_CAPCITY)
	{
		if (queue[i] == num)
		{
			return 1;
		}
	}
	return 0;

}

void Clear()
{
	/*
	void Clear ( void )
	removes all items in the queue.
*/

	size = front = back = 0;
}

void Print()
{
	/*
		void Print ( void )
		prints all items in the queue on ONE LINE with a space between each item and a linebreak at the end.  Note that the queue should be displayed horizontally on the page.  The first item added should be the first item displayed.
	*/
	for (int i = 0; i < size; ++i)
	{
		std::cout << queue[i] << " ";
	}
	std::cout << "\n";
}

int IsEmpty()
{
	/*
		int IsEmpty ( )
		returns 1 if empty, 0 if not empty.
	*/
	return size == 0 ? 1 : 0;
}

int Enqueue(int num)
{
	/**
	int Enqueue ( int num )
	adds num to the queue.  Return 0 if success.  Return -58 if queue is full.  Return -62 if the queue already has num.
	*/
	if (size == MAX_CAPCITY)
		return -58;


	if (Exists(num))
		return -62;

	queue[back] = num;
	back = (back + 1) % MAX_CAPCITY;
	size++;
	return 0;
}

int Dequeue(int& num)
{
	/*
		int Dequeue ( int& num )
		removes the front item in the queue and places it in num.  Return 0 if success.   Return -64 if queue is empty.
	*/
	if (IsEmpty() == 1)
		return -64;

	num = queue[front];

	for (int i = 0; i < size; ++i)
	{
		queue[i] = queue[i + 1];
	}
	size--;
	return 0;
}

int Mul()
{
	/*
		int Mul(void)
		multiplies the first two items in the queue and inserts the product in the front tof the queue.
		Return 0 if success.   Returns - 79  if there are not at least two items.  Returns -81 operation would cause an overflow.
		Returns -82 if the result of multiplying would cause a duplicate.
	*/
	

	if (size == MAX_CAPCITY) return -1;
	if (size < 2) return -79;

	int item_1 = queue[front];
	int nextIndex = (front + 1) % MAX_CAPCITY;
	int item_2 = queue[nextIndex];

	int multi = item_1 * item_2;



	if (Exists(multi)) return -82;
	
	for (int i = size - 1; i >= 0; i--)
	{
		queue[i + 1] = queue[i];
	}
	
	queue[front] = multi;
	size++;
	return 0;

}

int Reverse()
{
	int pointer1 = front;
	int pointer2 = back - 1;

	while (pointer1 < pointer2)
	{
		int temp = queue[pointer1];
		queue[pointer1] = queue[pointer2];
		queue[pointer2] = temp;

		pointer1 = (pointer1 + 1) % MAX_CAPCITY;
		pointer2 = (pointer2 - 1) % MAX_CAPCITY;

	}
	return 0;
}

int Peek(int& num)
{
	if (IsEmpty() == 1)
		return -88;

	num = queue[front];
	return 0;
}

/*








void Print ( void )
prints all items in the queue on ONE LINE with a space between each item and a linebreak at the end.  Note that the queue should be displayed horizontally on the page.  The first item added should be the first item displayed.

int Mul(void)
multiplies the first two items in the queue and inserts the product in the front tof the queue.  Return 0 if success.   Returns - 79  if there are not at least two items.  Returns -81 operation would cause an overflow.  Returns -82 if the result of multiplying would cause a duplicate.

int Reverse ( void )
reverses all items in the queue.  The first item becomes the last item.  The second item becomes the second to last item, etc.  Return 0 if success.

int Peek ( int& num )
gets the first item and places it in num, without removing it from the queue.  Return 0 if success. Return -88 if fail.
*/

