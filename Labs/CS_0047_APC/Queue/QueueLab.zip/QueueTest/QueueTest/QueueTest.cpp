#include <iostream>
#include "QueueI.h"

using namespace std;
int main()
{
	int a;
	int testNum = 1;
	int retVal;
	Print();

	Clear();


	retVal = Exists(5);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;


	retVal = Dequeue(a);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	retVal = Enqueue(5);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	retVal = Enqueue(6);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	retVal = Enqueue(7);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	retVal = Peek(a);
	cout << "Test " << testNum << " " << retVal << "  " << a << endl;
	testNum++;

	retVal = IsEmpty();
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	retVal = Enqueue(5);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	retVal = Enqueue(20);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	retVal = Enqueue(5);
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	Print();

	retVal = Reverse();
	cout << "Test " << testNum << " " << retVal << endl;
	testNum++;

	Print();

	retVal = Dequeue(a);
	cout << "Test " << testNum << " " << retVal << "  " << a << endl;
	testNum++;

	retVal = Mul();
	cout << "Test " << testNum << " " << retVal << "  " << a << endl;
	testNum++;

	Print();

	retVal = Mul();
	cout << "Test " << testNum << " " << retVal << "  " << a << endl;
	testNum++;

	Print();

	return 0;
}